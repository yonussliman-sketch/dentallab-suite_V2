// إشعارات FCM الخلفية (تعمل والتطبيق مغلق) — اختيارية وتتطلب خطة Blaze
const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");
admin.initializeApp();
const android = { notification: { channelId: "orders" } };

async function tokenOf(uid) {
  const u = await admin.firestore().doc(`users/${uid}`).get();
  return u.get("fcmToken");
}

exports.onCaseCreated = onDocumentCreated("cases/{id}", async (event) => {
  const k = event.data.data();
  await admin.messaging().send({
    topic: "labs",
    notification: { title: k.urgent ? "⚡ New case" : "New case", body: `${k.clinicName}` },
    android,
  });
});

exports.onCaseUpdated = onDocumentUpdated("cases/{id}", async (event) => {
  const b = event.data.before.data(), a = event.data.after.data();
  if (b.status === a.status) return;
  const token = await tokenOf(a.clinicId);
  if (!token) return;
  await admin.messaging().send({
    token, notification: { title: "Case update", body: `${a.clinicName || ""} — status ${a.status}` }, android,
  });
});

exports.onApptCreated = onDocumentCreated("appointments/{id}", async (event) => {
  const a = event.data.data();
  await admin.messaging().send({
    topic: "labs",
    notification: { title: "New appointment request", body: `${a.clinicName} — ${a.date} ${a.time}` },
    android,
  });
});

exports.onApptUpdated = onDocumentUpdated("appointments/{id}", async (event) => {
  const b = event.data.before.data(), a = event.data.after.data();
  if (b.status === a.status) return;
  const token = await tokenOf(a.clinicId);
  if (!token) return;
  await admin.messaging().send({
    token, notification: { title: "Appointment update", body: `${a.date} ${a.time}` }, android,
  });
});
