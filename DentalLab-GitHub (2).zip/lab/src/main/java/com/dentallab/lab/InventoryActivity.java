package com.dentallab.lab;
import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.dentallab.core.*;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** المخزون: اضغط لتعديل الكمية، اضغط مطولاً للحذف. ⚠ عند انخفاض الكمية */
public class InventoryActivity extends AppCompatActivity {
    private static final int LOW = 5;
    private ListView list;
    private ListenerRegistration reg;
    private List<InventoryItem> data = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.fragment_list);
        Edge.apply(this);
        setTitle(R.string.more_inventory);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        list = findViewById(R.id.list);
        list.setEmptyView(findViewById(R.id.empty));
        findViewById(R.id.fab).setOnClickListener(x ->
            Ui.form(this, R.string.inv_new, new int[]{R.string.hint_item_name, R.string.hint_qty}, f -> {
                if (f[0].isEmpty()) return;
                InventoryItem i = new InventoryItem();
                i.name = f[0]; i.quantity = (int) Ui.num(f[1]);
                Repo.db().collection("inventory").add(i);
            }));
        list.setOnItemClickListener((p, v, pos, id) -> {
            InventoryItem i = data.get(pos);
            Ui.form(this, R.string.inv_edit, new int[]{R.string.hint_qty}, f ->
                    Repo.db().collection("inventory").document(i.id).update("quantity", (int) Ui.num(f[0])));
        });
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            InventoryItem i = data.get(pos);
            Ui.confirm(this, R.string.confirm_delete, () -> Repo.db().collection("inventory").document(i.id).delete());
            return true;
        });
        reg = Repo.db().collection("inventory").addSnapshotListener((snap, e) -> {
            if (snap == null) return;
            data = snap.toObjects(InventoryItem.class);
            Collections.sort(data, (a, b2) -> Ui.nz(a.name).compareTo(Ui.nz(b2.name)));
            List<CardAdapter.Row> rows = new ArrayList<>();
            for (InventoryItem i : data)
                rows.add(new CardAdapter.Row(i.name, getString(R.string.inv_hint),
                        (i.quantity <= LOW ? "\u26A0 " : "") + i.quantity, i.quantity <= LOW ? 0xFFC62828 : 0xFF2E7D32));
            list.setAdapter(new CardAdapter(this, rows));
        });
    }

    @Override protected void onDestroy() {
        if (reg != null) reg.remove();
        super.onDestroy();
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
