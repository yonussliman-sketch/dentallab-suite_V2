# Dental Lab Suite — تطبيق العيادات + تطبيق المعمل

## بناء ملف APK تلقائياً عبر GitHub (بدون Android Studio)
1. ارفع كل ملفات هذا المجلد إلى مستودع GitHub (الفرع `main`).
2. أضف ملف `google-services.json` الخاص بمشروع Firebase بإحدى طريقتين:
   - **الأسهل:** Settings ← Secrets and variables ← Actions ← New repository secret
     الاسم `GOOGLE_SERVICES_JSON` والقيمة = كل نص الملف (من Firebase Console ← Project settings ← تطبيقاتك).
   - أو ارفع الملف داخل المجلدين `clinic/` و `lab/`.
3. تبويب **Actions** ← **Build APK** ← **Run workflow**.
4. بعد 5–10 دقائق افتح **Releases** من الجوال ← نزّل `DentalLab-Clinics.apk` و `DentalLab-Lab.apk` وثبّتهما.

مسارات الإخراج داخل البناء:
- `clinic/build/outputs/apk/debug/clinic-debug.apk`
- `lab/build/outputs/apk/debug/lab-debug.apk`
