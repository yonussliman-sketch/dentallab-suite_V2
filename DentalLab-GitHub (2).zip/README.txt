=====================================================================
 DentalLabSuite — نسخة Firebase
 تطبيقان في مشروع واحد:  clinic (العيادات)  +  lab (إدارة المعمل)  + مكتبة مشتركة core
 اللغات: العربية والإنجليزية (من: المزيد ← اللغة)
=====================================================================

1) إعداد Firebase (مرة واحدة)
 أ) https://console.firebase.google.com ← Add project
 ب) Add app ← Android ← مرتين:   com.dentallab.clinic   ثم   com.dentallab.lab
 ج) حمّل google-services.json (يحتوي التطبيقين) وانسخه إلى المجلدين:
        DentalLabSuite/clinic/google-services.json
        DentalLabSuite/lab/google-services.json
    (بدون هذا الملف يفشل البناء — هذا سبب أشهر خطأ عند أول تشغيل)
 د) Build ← Authentication ← Sign-in method ← فعّل Email/Password
 هـ) Build ← Firestore Database ← Create database ← تبويب Rules ← الصق firestore.rules ← Publish
 و) Build ← Storage ← Get started ← تبويب Rules ← الصق storage.rules ← Publish
    (Storage يتطلب ربط حساب فوترة Blaze وفيه حصة مجانية شهرية؛ وإن ظهرت رسالة صلاحيات بين Storage وFirestore فوافق عليها)

2) التشغيل
 - أحدث Android Studio (JDK 17 مدمج) ← File ← Open ← مجلد DentalLabSuite ← انتظر Gradle Sync.
 - اختر الوحدة clinic أو lab من القائمة العلوية ثم Run.
 - أنشئ حساب المعمل أولاً من تطبيق lab (أول حساب يصبح المالك ولا يمكن إنشاء ثانٍ)، ثم حساب عيادة من تطبيق clinic.

3) الاستخدام (دورة العمل)
 - العيادة ترسل الحالة ← المعمل "يستلمها" (زر استلام أو "استلام كل الحالات الجديدة") ← يعمل عليها ويغيّر مراحلها
   (تم الاستلام / قيد التصنيع / فحص الجودة / جاهزة) ← "إرجاع الشغل المنجز للعيادة" يرفع ملفات الشغل وتصل العيادة بإشعار.
 - العيادة: "حالة جديدة" ← اختيار الأسنان من صورة الفكين ← إرفاق ملفات (STL/صور/PDF/ZIP...) ← "حفظ الحالة"
   أو "حفظ وإضافة حالة أخرى" لإرسال عدة حالات لعدة مرضى (اسم المريض اختياري). تصل للمعمل فوراً.
 - المعمل: يستقبل إشعاراً، يفتح الحالة، ينزّل/يفتح الملفات، يغيّر الحالة ويحدد السعر ويكتب ملاحظة،
   ويتواصل مع الطبيب واتساب/اتصال، ويسجل الدفعات من تبويب "الأطباء".
 - رقم التواصل +967777531968 في آخر شاشة "المزيد" فقط.

3-ب) ميزات إضافية
 - استعادة كلمة المرور: زر "نسيت كلمة المرور؟" في شاشة الدخول (يصل رابط إلى البريد).
 - تصدير التقارير (PDF / Excel) في تطبيق المعمل: الإعدادات ← "تصدير تقرير".
 - الإعدادات: الملف الشخصي، اللغة، المخزون والتقارير (للمعمل)، تقييم التطبيق، مشاركته، الخصوصية، تسجيل الخروج، حذف الحساب.
 - التبويبات ظاهرة دائماً بأسمائها في التطبيقين.

3-ج) النسخ الاحتياطي لقاعدة البيانات (مهم)
        ./backup/enable_backups.sh PROJECT_ID      (ويندوز: backup\enable_backups.bat PROJECT_ID)
    يفعّل نسخة يومية + أسبوعية واستعادة لحظية. التفاصيل في backup/README_backup.txt. (يتطلب Blaze)

4) سياسة الخصوصية (مطلوبة في Google Play) — مجاناً عبر Firebase Hosting
        npm i -g firebase-tools && firebase login
        firebase deploy --only hosting
    الرابط: https://PROJECT_ID.web.app/privacy.html  (ضعه في Play Console؛ وزر "سياسة الخصوصية" في التطبيق يفتحه تلقائياً)

5) إشعارات والتطبيق مغلق (اختياري، يتطلب Blaze)
        cd functions && npm install && cd ..
        firebase deploy --only functions
    أثناء فتح التطبيق تعمل الإشعارات بدون هذه الخطوة.

6) النشر على Google Play
 - هذه النسخة مضبوطة على compileSdk/targetSdk 34 لتفتح في أغلب إصدارات Android Studio بلا أخطاء.
 - Google Play يشترط للتطبيقات الجديدة استهداف Android 16 (API 36): قبل النشر افتح
   Tools ← AGP Upgrade Assistant ليرفع نسخة Android Gradle Plugin، ثم غيّر compileSdk وtargetSdk إلى 36 في
   core/build.gradle و clinic/build.gradle و lab/build.gradle.
 - مفتاح التوقيع:
        keytool -genkeypair -v -keystore dentallab.jks -alias dentallab -keyalg RSA -keysize 2048 -validity 10000
   انسخ keystore.properties.example إلى keystore.properties وعبّئه، ثم Build ← Generate Signed App Bundle.
 - ملفات المتجر في PlayStore/ (أيقونات 512، صور العرض، الوصف، أمان البيانات، سياسة الخصوصية).
 - المراجعون يحتاجون حساباً تجريبياً (Play Console ← App access).
 - حذف الحساب متوفر داخل التطبيق (المزيد ← حذف حسابي) كما تشترط Google Play.
