package com.dentallab.core;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** كاتب ملفات Excel (.xlsx) بدون مكتبات خارجية — يدعم العربية واتجاه RTL */
public class XlsxWriter {
    public static class Sheet {
        public final String name;
        public final List<Object[]> rows = new ArrayList<>(); // الصف الأول = العناوين، القيم String أو Double
        public int[] widths;
        public Sheet(String name) { this.name = name; }
    }

    private static final String XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
    private static final String NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static final String REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

    public static void write(File out, List<Sheet> sheets, boolean rtl) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))) {
            StringBuilder ct = new StringBuilder(XML)
                    .append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
                    .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
                    .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
                    .append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
                    .append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            for (int i = 1; i <= sheets.size(); i++)
                ct.append("<Override PartName=\"/xl/worksheets/sheet").append(i)
                  .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            ct.append("</Types>");
            put(z, "[Content_Types].xml", ct.toString());

            put(z, "_rels/.rels", XML + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                    + "<Relationship Id=\"rId1\" Type=\"" + REL + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");

            StringBuilder wb = new StringBuilder(XML).append("<workbook xmlns=\"").append(NS).append("\" xmlns:r=\"").append(REL).append("\"><sheets>");
            StringBuilder rels = new StringBuilder(XML)
                    .append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (int i = 1; i <= sheets.size(); i++) {
                wb.append("<sheet name=\"").append(esc(safeName(sheets.get(i - 1).name))).append("\" sheetId=\"").append(i)
                  .append("\" r:id=\"rId").append(i).append("\"/>");
                rels.append("<Relationship Id=\"rId").append(i).append("\" Type=\"").append(REL)
                    .append("/worksheet\" Target=\"worksheets/sheet").append(i).append(".xml\"/>");
            }
            wb.append("</sheets></workbook>");
            rels.append("<Relationship Id=\"rIdS\" Type=\"").append(REL).append("/styles\" Target=\"styles.xml\"/></Relationships>");
            put(z, "xl/workbook.xml", wb.toString());
            put(z, "xl/_rels/workbook.xml.rels", rels.toString());

            put(z, "xl/styles.xml", XML + "<styleSheet xmlns=\"" + NS + "\">"
                    + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
                    + "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>"
                    + "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFCDE9E4\"/></patternFill></fill></fills>"
                    + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                    + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                    + "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                    + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs>"
                    + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");

            for (int i = 1; i <= sheets.size(); i++) put(z, "xl/worksheets/sheet" + i + ".xml", sheetXml(sheets.get(i - 1), rtl));
        }
    }

    private static String sheetXml(Sheet s, boolean rtl) {
        StringBuilder sb = new StringBuilder(XML).append("<worksheet xmlns=\"").append(NS).append("\">");
        sb.append("<sheetViews><sheetView workbookViewId=\"0\"").append(rtl ? " rightToLeft=\"1\"" : "").append("/></sheetViews>");
        if (s.widths != null) {
            sb.append("<cols>");
            for (int i = 0; i < s.widths.length; i++)
                sb.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1).append("\" width=\"")
                  .append(s.widths[i]).append("\" customWidth=\"1\"/>");
            sb.append("</cols>");
        }
        sb.append("<sheetData>");
        for (int r = 0; r < s.rows.size(); r++) {
            sb.append("<row r=\"").append(r + 1).append("\">");
            Object[] row = s.rows.get(r);
            for (int c = 0; c < row.length; c++) {
                String ref = col(c) + (r + 1);
                String style = r == 0 ? " s=\"1\"" : "";
                Object v = row[c];
                if (v instanceof Double) sb.append("<c r=\"").append(ref).append("\"").append(style).append("><v>").append(v).append("</v></c>");
                else sb.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"").append(style).append("><is><t xml:space=\"preserve\">")
                        .append(esc(v == null ? "" : v.toString())).append("</t></is></c>");
            }
            sb.append("</row>");
        }
        sb.append("</sheetData></worksheet>");
        return sb.toString();
    }

    private static String col(int i) {
        StringBuilder s = new StringBuilder();
        i++;
        while (i > 0) { int m = (i - 1) % 26; s.insert(0, (char) ('A' + m)); i = (i - 1) / 26; }
        return s.toString();
    }

    private static String safeName(String n) {
        String s = n.replaceAll("[\\\\/?*\\[\\]:]", " ").trim();
        if (s.isEmpty()) s = "Sheet";
        return s.length() > 31 ? s.substring(0, 31) : s;
    }

    private static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '&') b.append("&amp;");
            else if (ch == '<') b.append("&lt;");
            else if (ch == '>') b.append("&gt;");
            else if (ch == '"') b.append("&quot;");
            else if (ch < 0x20 && ch != '\n' && ch != '\t') continue;
            else b.append(ch);
        }
        return b.toString();
    }

    private static void put(ZipOutputStream z, String name, String content) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }
}
