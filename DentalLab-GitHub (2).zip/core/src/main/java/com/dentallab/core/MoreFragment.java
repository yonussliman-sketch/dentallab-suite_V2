package com.dentallab.core;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.List;

/** الإعدادات: الملف الشخصي، اللغة، (المخزون والتقارير للمعمل)، تقييم/مشاركة، الخصوصية، حول، خروج، حذف — وفي آخر الشاشة رقم التواصل */
public class MoreFragment extends Fragment {
    private static final int PROFILE = 0, LANG = 1, INVENTORY = 2, EXPORT = 3, RATE = 4, SHARE = 5, PRIVACY = 6, ABOUT = 7, LOGOUT = 8, DELETE = 9;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        v.findViewById(R.id.empty).setVisibility(View.GONE);
        final Host host = (Host) requireActivity();
        ListView list = v.findViewById(R.id.list);

        final List<Integer> actions = new ArrayList<>();
        List<CardAdapter.Row> rows = new ArrayList<>();
        add(rows, actions, PROFILE, "\uD83D\uDC64  " + getString(R.string.more_profile), Profile.name(requireContext()));
        add(rows, actions, LANG, "\uD83C\uDF10  " + getString(R.string.more_language), null);
        if (host.isLab()) {
            add(rows, actions, INVENTORY, "\uD83D\uDCE6  " + getString(R.string.more_inventory), null);
            add(rows, actions, EXPORT, "\uD83D\uDCCA  " + getString(R.string.more_export), getString(R.string.more_export_sub));
        }
        add(rows, actions, RATE, "\u2B50  " + getString(R.string.more_rate), null);
        add(rows, actions, SHARE, "\uD83D\uDD17  " + getString(R.string.more_share), null);
        add(rows, actions, PRIVACY, "\uD83D\uDD12  " + getString(R.string.more_privacy), null);
        add(rows, actions, ABOUT, "\u2139\uFE0F  " + getString(R.string.more_about), null);
        add(rows, actions, LOGOUT, "\uD83D\uDEAA  " + getString(R.string.more_logout), null);
        add(rows, actions, DELETE, "\uD83D\uDDD1  " + getString(R.string.more_delete), null);

        View footer = inf.inflate(R.layout.view_contact, list, false);
        ((TextView) footer.findViewById(R.id.tvNumber)).setText(Constants.CONTACT_PHONE);
        footer.findViewById(R.id.btnWa).setOnClickListener(x ->
                Ui.whatsapp(requireContext(), Constants.CONTACT_PHONE, getString(R.string.contact_msg)));
        footer.findViewById(R.id.btnCall).setOnClickListener(x -> Ui.call(requireContext(), Constants.CONTACT_PHONE));
        list.addFooterView(footer, null, false);
        list.setAdapter(new CardAdapter(requireContext(), rows));

        list.setOnItemClickListener((p, view, pos, id) -> {
            if (pos >= actions.size()) return;
            switch (actions.get(pos)) {
                case PROFILE: startActivity(new Intent(requireContext(), SetupActivity.class).putExtra("lab", host.isLab())); break;
                case LANG: Lang.showDialog(requireActivity()); break;
                case INVENTORY: host.openInventory(); break;
                case EXPORT: ReportExporter.choose(requireActivity()); break;
                case RATE: rate(); break;
                case SHARE: share(); break;
                case PRIVACY: privacy(); break;
                case ABOUT: about(); break;
                case LOGOUT: Ui.confirm(requireContext(), R.string.more_logout, () -> AccountUtil.logout(requireActivity(), host.isLab())); break;
                default: AccountUtil.deleteAccount(requireActivity(), host.isLab());
            }
        });
        return v;
    }

    private static void add(List<CardAdapter.Row> rows, List<Integer> actions, int action, String title, String sub) {
        rows.add(new CardAdapter.Row(title, sub, null, 0));
        actions.add(action);
    }

    private String storeUrl() { return "https://play.google.com/store/apps/details?id=" + requireContext().getPackageName(); }

    private void rate() {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + requireContext().getPackageName()))); }
        catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(storeUrl()))); }
            catch (Exception e2) { Ui.toast(requireContext(), R.string.err_open); }
        }
    }

    private void share() {
        Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, getString(R.string.share_text, getString(R.string.app_name), storeUrl()));
        startActivity(Intent.createChooser(s, getString(R.string.more_share)));
    }

    /** صفحة سياسة الخصوصية تُستضاف على Firebase Hosting: https://PROJECT_ID.web.app/privacy.html */
    private void privacy() {
        try {
            String id = FirebaseApp.getInstance().getOptions().getProjectId();
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://" + id + ".web.app/privacy.html")));
        } catch (Exception e) { Ui.toast(requireContext(), R.string.err_open); }
    }

    private void about() {
        String ver = "";
        try {
            PackageInfo pi = requireContext().getPackageManager().getPackageInfo(requireContext().getPackageName(), 0);
            ver = pi.versionName;
        } catch (Exception ignored) { }
        new AlertDialog.Builder(requireContext()).setTitle(R.string.more_about)
                .setMessage(getString(R.string.about_text, ver))
                .setPositiveButton(R.string.btn_close, null).show();
    }
}
