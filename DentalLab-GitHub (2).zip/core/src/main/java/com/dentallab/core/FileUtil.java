package com.dentallab.core;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.MimeTypeMap;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.storage.UploadTask;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * رفع وتنزيل ملفات الحالات (STL / صور / PDF / أي صيغة).
 * الأولوية لـ Firebase Storage؛ وإن لم يكن متاحاً (لم يُفعَّل أو الخطة المجانية) يُحفظ الملف تلقائياً
 * على Firestore مقسّماً إلى أجزاء 512KB، فيعمل الإرسال في كل الحالات.
 */
public class FileUtil {
    public interface Progress { void onProgress(int percent); }
    public interface Done { void onDone(CaseFile file, Exception error); }

    private static final int CHUNK = 512 * 1024;
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static boolean storageOk = true;

    public static String displayName(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && q.getString(i) != null) return q.getString(i);
            }
        } catch (Exception ignored) { }
        return "file_" + System.currentTimeMillis();
    }

    public static long sizeOf(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0) return q.getLong(i);
            }
        } catch (Exception ignored) { }
        return 0;
    }

    public static String safe(String name) {
        String s = name.replaceAll("[^A-Za-z0-9._-]", "_");
        return s.length() > 80 ? s.substring(s.length() - 80) : s;
    }

    public static String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(Locale.US, "%.1f KB", b / 1024.0);
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    // ------------------------------------------------------------------ رفع
    public static void upload(final Context c, final Uri uri, final String clinicId, final String name,
                              final long size, final Progress p, final Done d) {
        String bucket = "";
        try { bucket = FirebaseApp.getInstance().getOptions().getStorageBucket(); } catch (Exception ignored) { }
        if (storageOk && bucket != null && !bucket.isEmpty()) {
            final String path = "cases/" + clinicId + "/" + System.currentTimeMillis() + "_" + safe(name);
            UploadTask t = Repo.storage().getReference(path).putFile(uri);
            t.addOnProgressListener(s -> p.onProgress((int) (100.0 * s.getBytesTransferred() / Math.max(1, s.getTotalByteCount()))));
            t.addOnSuccessListener(s -> {
                CaseFile f = new CaseFile();
                f.name = name; f.path = path; f.size = size;
                d.onDone(f, null);
            }).addOnFailureListener(e -> {
                storageOk = false; // Storage غير جاهز: نكمل عبر Firestore
                uploadChunks(c, uri, clinicId, name, size, p, d);
            });
        } else {
            uploadChunks(c, uri, clinicId, name, size, p, d);
        }
    }

    private static int readFully(InputStream in, byte[] buf) throws IOException {
        int off = 0;
        while (off < buf.length) {
            int r = in.read(buf, off, buf.length - off);
            if (r < 0) break;
            off += r;
        }
        return off;
    }

    private static void uploadChunks(final Context c, final Uri uri, final String clinicId, final String name,
                                     final long size, final Progress p, final Done d) {
        EX.execute(() -> {
            CaseFile f = null;
            Exception err = null;
            try {
                DocumentReference parent = Repo.db().collection("files").document();
                Map<String, Object> meta = new HashMap<>();
                meta.put("owner", Repo.uid());
                meta.put("clinicId", clinicId);
                meta.put("name", name);
                meta.put("t", System.currentTimeMillis());
                Tasks.await(parent.set(meta));
                int n = 0;
                long done = 0;
                try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IOException("cannot read file");
                    byte[] buf = new byte[CHUNK];
                    while (true) {
                        int len = readFully(in, buf);
                        if (len <= 0) break;
                        byte[] part = len == buf.length ? buf : Arrays.copyOf(buf, len);
                        Map<String, Object> m = new HashMap<>();
                        m.put("i", n);
                        m.put("d", Base64.encodeToString(part, Base64.NO_WRAP));
                        Tasks.await(parent.collection("parts").document(String.valueOf(n)).set(m));
                        n++;
                        done += len;
                        final int pct = size > 0 ? (int) Math.min(100, 100.0 * done / size) : 0;
                        H.post(() -> p.onProgress(pct));
                    }
                }
                if (n == 0) throw new IOException("empty file");
                f = new CaseFile();
                f.name = name; f.path = ""; f.fid = parent.getId(); f.parts = n;
                f.size = size > 0 ? size : done;
            } catch (Exception e) {
                err = e;
            }
            final CaseFile ff = f;
            final Exception ee = err;
            H.post(() -> d.onDone(ff, ee));
        });
    }

    // ------------------------------------------------------------------ حذف
    public static void deleteAll(List<CaseFile> files) {
        if (files == null) return;
        for (final CaseFile f : files) {
            if (f.fid != null && !f.fid.isEmpty()) {
                EX.execute(() -> {
                    try {
                        DocumentReference parent = Repo.db().collection("files").document(f.fid);
                        for (int i = 0; i < f.parts; i++)
                            Tasks.await(parent.collection("parts").document(String.valueOf(i)).delete());
                        Tasks.await(parent.delete());
                    } catch (Exception ignored) { }
                });
            } else if (f.path != null && !f.path.isEmpty()) {
                Repo.storage().getReference(f.path).delete();
            }
        }
    }

    // ------------------------------------------------------------------ فتح / مشاركة / حفظ
    private static String mimeOf(String name) {
        int i = name.lastIndexOf('.');
        if (i > 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(i + 1).toLowerCase(Locale.US));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    /** قائمة: فتح / مشاركة / حفظ في التنزيلات */
    public static void openOrShare(final Context c, final CaseFile f) {
        String[] items = {c.getString(R.string.file_open), c.getString(R.string.file_share), c.getString(R.string.file_save)};
        new AlertDialog.Builder(c).setTitle(f.name).setItems(items, (d, w) -> {
            if (w == 0) fetch(c, f, true);
            else if (w == 1) fetch(c, f, false);
            else saveToDownloads(c, f);
        }).setNegativeButton(R.string.btn_close, null).show();
    }

    private static void fetch(final Context c, final CaseFile f, final boolean view) {
        final AlertDialog dlg = Ui.busy(c, R.string.msg_downloading);
        File dir = new File(c.getCacheDir(), "dl");
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File o : old) o.delete();
        final File dest = new File(dir, safe(f.name));

        if (f.fid != null && !f.fid.isEmpty()) {
            EX.execute(() -> {
                Exception err = null;
                try (FileOutputStream out = new FileOutputStream(dest)) {
                    DocumentReference parent = Repo.db().collection("files").document(f.fid);
                    for (int i = 0; i < f.parts; i++) {
                        DocumentSnapshot s = Tasks.await(parent.collection("parts").document(String.valueOf(i)).get());
                        String b = s.getString("d");
                        if (b == null) throw new IOException("missing part " + i);
                        out.write(Base64.decode(b, Base64.NO_WRAP));
                    }
                } catch (Exception e) {
                    err = e;
                }
                final Exception ee = err;
                H.post(() -> {
                    dlg.dismiss();
                    if (ee != null) Ui.toast(c, c.getString(R.string.err_download, ee.getLocalizedMessage()));
                    else deliver(c, dest, f, view);
                });
            });
            return;
        }

        Repo.storage().getReference(f.path).getFile(dest).addOnSuccessListener(t -> {
            dlg.dismiss();
            deliver(c, dest, f, view);
        }).addOnFailureListener(e -> {
            dlg.dismiss();
            Ui.toast(c, c.getString(R.string.err_download, e.getLocalizedMessage()));
        });
    }

    private static void deliver(Context c, File dest, CaseFile f, boolean view) {
        Uri u = FileProvider.getUriForFile(c, c.getPackageName() + ".files", dest);
        if (view) {
            Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, mimeOf(f.name))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { c.startActivity(i); return; } catch (Exception ignored) { }
        }
        Intent s = new Intent(Intent.ACTION_SEND).setType("application/octet-stream")
                .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        c.startActivity(Intent.createChooser(s, c.getString(R.string.share_title)));
    }

    private static void saveToDownloads(final Context c, final CaseFile f) {
        if (f.fid != null && !f.fid.isEmpty()) { fetch(c, f, false); return; } // يظهر خيار "حفظ" ضمن قائمة المشاركة
        Repo.storage().getReference(f.path).getDownloadUrl().addOnSuccessListener(u -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(u);
                r.setTitle(f.name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, f.name.replaceAll("[\\\\/:*?\"<>|]", "_"));
                ((DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Ui.toast(c, R.string.toast_download);
            } catch (Exception e) {
                Ui.toast(c, c.getString(R.string.err_download, e.getLocalizedMessage()));
            }
        }).addOnFailureListener(e -> Ui.toast(c, c.getString(R.string.err_download, e.getLocalizedMessage())));
    }
}
