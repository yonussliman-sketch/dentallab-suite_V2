package com.dentallab.core;
import com.google.firebase.messaging.FirebaseMessaging;

public class Push {
    public static void register(boolean lab) {
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(t ->
                Repo.db().collection("users").document(Repo.uid()).update("fcmToken", t));
        if (lab) FirebaseMessaging.getInstance().subscribeToTopic("labs");
    }
    public static void unregister(boolean lab) {
        if (lab) FirebaseMessaging.getInstance().unsubscribeFromTopic("labs");
    }
}
