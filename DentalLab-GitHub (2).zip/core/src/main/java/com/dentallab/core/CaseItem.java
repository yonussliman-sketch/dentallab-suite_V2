package com.dentallab.core;
import com.google.firebase.firestore.DocumentId;
import java.util.ArrayList;
import java.util.List;

/** حالة واحدة. status: 1 مُرسلة، 2 تم الاستلام، 3 قيد التصنيع، 4 فحص الجودة، 5 جاهزة، 6 أُرجعت للعيادة */
public class CaseItem {
    @DocumentId public String id;
    public String clinicId, clinicName, clinicPhone, patientRef, teeth, shade, dueDate, notes, labNote;
    public int workType, status;
    public boolean urgent;
    public double price;
    public long createdAt, updatedAt;
    public List<CaseFile> files = new ArrayList<>();
    /** ملفات الشغل المُرجَع من المعمل للعيادة */
    public List<CaseFile> resultFiles = new ArrayList<>();
    public long receivedAt, returnedAt;
    public CaseItem() {}
}
