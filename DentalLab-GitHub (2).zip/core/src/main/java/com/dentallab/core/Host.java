package com.dentallab.core;

/** تنفّذها الشاشة الرئيسية في كل تطبيق */
public interface Host {
    boolean isLab();
    void openInventory();
}
