package com.dentallab.core;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class Ui {
    public static final int[] STATUS_RES = {R.string.st_draft, R.string.st_new, R.string.st_received,
            R.string.st_progress, R.string.st_qc, R.string.st_ready, R.string.st_delivered};
    public static final int[] STATUS_COLOR = {0xFF78909C, 0xFF1976D2, 0xFF00897B, 0xFFEF6C00, 0xFF8E24AA, 0xFF2E7D32, 0xFF546E7A};
    public static final int[] APPT_RES = {R.string.ap_pending, R.string.ap_confirmed, R.string.ap_rejected};
    public static final int[] APPT_COLOR = {0xFF1976D2, 0xFF2E7D32, 0xFFC62828};
    private static final String[] SHADE_CODES = {"A1", "A2", "A3", "A3.5", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4",
            "D2", "D3", "D4", "BL1", "BL2", "BL3", "BL4"};

    public interface OnSubmit { void run(String[] values); }
    public interface OnText { void run(String text); }

    public static String statusLabel(Context c, int s) { return c.getString(STATUS_RES[Math.max(0, Math.min(6, s))]); }
    public static int statusColor(int s) { return STATUS_COLOR[Math.max(0, Math.min(6, s))]; }
    public static String apptLabel(Context c, int s) { return c.getString(APPT_RES[Math.max(0, Math.min(2, s))]); }
    public static int apptColor(int s) { return APPT_COLOR[Math.max(0, Math.min(2, s))]; }

    public static String[] statusLabels(Context c, int from) {
        List<String> l = new ArrayList<>();
        for (int i = from; i < STATUS_RES.length; i++) l.add(c.getString(STATUS_RES[i]));
        return l.toArray(new String[0]);
    }

    public static String workLabel(Context c, int idx) {
        String[] a = c.getResources().getStringArray(R.array.work_types);
        return a[Math.max(0, Math.min(a.length - 1, idx))];
    }

    public static List<String> shades(Context c) {
        List<String> l = new ArrayList<>();
        l.add(c.getString(R.string.unspecified));
        for (String s : SHADE_CODES) l.add(s);
        return l;
    }

    public static String nz(String s) { return s == null ? "" : s; }
    public static double num(String s) {
        try { return Double.parseDouble(s.trim()); } catch (Exception ex) { return 0; }
    }
    public static String money(double d) { return String.format(Locale.US, "%.2f", d); }
    public static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_LONG).show(); }
    public static void toast(Context c, int res) { Toast.makeText(c, res, Toast.LENGTH_LONG).show(); }

    /** عنوان الحالة: للعيادة = نوع العمل (+المريض)، وللمعمل = اسم الطبيب */
    public static String caseTitle(Context c, CaseItem k, boolean lab) {
        String ref = nz(k.patientRef).trim();
        if (lab) return "\uD83D\uDC68\u200D\u2695\uFE0F " + nz(k.clinicName);
        return workLabel(c, k.workType) + (ref.isEmpty() ? "" : " \u2014 " + ref);
    }

    public static GradientDrawable pill(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(200f);
        return g;
    }

    public static void form(Context c, int title, int[] hints, OnSubmit cb) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (20 * c.getResources().getDisplayMetrics().density);
        l.setPadding(p, p / 2, p, 0);
        EditText[] e = new EditText[hints.length];
        for (int i = 0; i < hints.length; i++) {
            e[i] = new EditText(c);
            e[i].setHint(hints[i]);
            l.addView(e[i]);
        }
        ScrollView sv = new ScrollView(c);
        sv.addView(l);
        new AlertDialog.Builder(c).setTitle(title).setView(sv)
                .setPositiveButton(R.string.btn_save, (d, w) -> {
                    String[] v = new String[e.length];
                    for (int i = 0; i < e.length; i++) v[i] = e[i].getText().toString().trim();
                    cb.run(v);
                })
                .setNegativeButton(R.string.btn_cancel, null).show();
    }

    public static void confirm(Context c, int title, Runnable yes) {
        new AlertDialog.Builder(c).setTitle(title)
                .setPositiveButton(R.string.btn_yes, (d, w) -> yes.run())
                .setNegativeButton(R.string.btn_no, null).show();
    }

    public static AlertDialog busy(Context c, int msg) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        int p = (int) (24 * c.getResources().getDisplayMetrics().density);
        l.setPadding(p, p, p, p);
        l.addView(new ProgressBar(c));
        TextView t = new TextView(c);
        t.setText(msg);
        t.setPadding(p / 2, 0, p / 2, 0);
        l.addView(t);
        AlertDialog d = new AlertDialog.Builder(c).setView(l).setCancelable(false).create();
        d.show();
        return d;
    }

    public static void pickDate(Context c, OnText cb) {
        Calendar k = Calendar.getInstance();
        new DatePickerDialog(c, (v, y, m, d) -> cb.run(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)),
                k.get(Calendar.YEAR), k.get(Calendar.MONTH), k.get(Calendar.DAY_OF_MONTH)).show();
    }

    public static void pickTime(Context c, OnText cb) {
        Calendar k = Calendar.getInstance();
        new TimePickerDialog(c, (v, h, m) -> cb.run(String.format(Locale.US, "%02d:%02d", h, m)),
                k.get(Calendar.HOUR_OF_DAY), k.get(Calendar.MINUTE), true).show();
    }

    public static void whatsapp(Context c, String phone, String msg) {
        String digits = nz(phone).replaceAll("[^0-9]", "");
        if (digits.isEmpty()) { toast(c, R.string.err_no_number); return; }
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(msg))));
        } catch (Exception e) { toast(c, R.string.err_open); }
    }

    public static void call(Context c, String phone) {
        if (nz(phone).isEmpty()) { toast(c, R.string.err_no_number); return; }
        try { c.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone))); }
        catch (Exception e) { toast(c, R.string.err_open); }
    }
}
