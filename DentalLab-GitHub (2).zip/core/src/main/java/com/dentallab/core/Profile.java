package com.dentallab.core;
import android.content.Context;
import android.content.SharedPreferences;

/** نسخة محلية من بيانات المستخدم (الاسم + الدولة + الرقم + الدور) */
public class Profile {
    private static SharedPreferences p(Context c) { return c.getSharedPreferences("profile", Context.MODE_PRIVATE); }
    public static boolean exists(Context c) { return p(c).contains("role"); }
    public static String name(Context c) { return p(c).getString("name", ""); }
    public static String iso(Context c) { return p(c).getString("iso", ""); }
    public static String national(Context c) { return p(c).getString("national", ""); }
    public static String e164(Context c) { return p(c).getString("e164", ""); }
    public static boolean isLab(Context c) { return "lab".equals(p(c).getString("role", "")); }
    public static void save(Context c, String name, String iso, String national, String e164, String role) {
        p(c).edit().putString("name", name).putString("iso", iso).putString("national", national)
                .putString("e164", e164).putString("role", role).apply();
    }
    public static void clear(Context c) { p(c).edit().clear().apply(); }
}
