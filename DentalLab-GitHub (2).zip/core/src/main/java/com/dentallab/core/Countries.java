package com.dentallab.core;
import android.content.Context;
import android.telephony.TelephonyManager;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** الدول ورموز الاتصال والأعلام. أسماء الدول تُعرض بلغة التطبيق الحالية تلقائياً. */
public class Countries {
    private static final String DATA =
        "AF:93,AX:358,AL:355,DZ:213,AS:1,AD:376,AO:244,AI:1,AG:1,AR:54,AM:374,AW:297,AU:61,AT:43,AZ:994,BS:1,BH:973,BD:880,BB:1,BY:375,"
      + "BE:32,BZ:501,BJ:229,BM:1,BT:975,BO:591,BQ:599,BA:387,BW:267,BR:55,IO:246,VG:1,BN:673,BG:359,BF:226,BI:257,KH:855,CM:237,CA:1,CV:238,"
      + "KY:1,CF:236,TD:235,CL:56,CN:86,CX:61,CC:61,CO:57,KM:269,CG:242,CD:243,CK:682,CR:506,CI:225,HR:385,CU:53,CW:599,CY:357,CZ:420,DK:45,"
      + "DJ:253,DM:1,DO:1,EC:593,EG:20,SV:503,GQ:240,ER:291,EE:372,SZ:268,ET:251,FK:500,FO:298,FJ:679,FI:358,FR:33,GF:594,PF:689,GA:241,GM:220,"
      + "GE:995,DE:49,GH:233,GI:350,GR:30,GL:299,GD:1,GP:590,GU:1,GT:502,GG:44,GN:224,GW:245,GY:592,HT:509,HN:504,HK:852,HU:36,IS:354,IN:91,"
      + "ID:62,IR:98,IQ:964,IE:353,IM:44,IL:972,IT:39,JM:1,JP:81,JE:44,JO:962,KZ:7,KE:254,KI:686,XK:383,KW:965,KG:996,LA:856,LV:371,LB:961,"
      + "LS:266,LR:231,LY:218,LI:423,LT:370,LU:352,MO:853,MG:261,MW:265,MY:60,MV:960,ML:223,MT:356,MH:692,MQ:596,MR:222,MU:230,YT:262,MX:52,"
      + "FM:691,MD:373,MC:377,MN:976,ME:382,MS:1,MA:212,MZ:258,MM:95,NA:264,NR:674,NP:977,NL:31,NC:687,NZ:64,NI:505,NE:227,NG:234,NU:683,"
      + "NF:672,KP:850,MK:389,MP:1,NO:47,OM:968,PK:92,PW:680,PS:970,PA:507,PG:675,PY:595,PE:51,PH:63,PL:48,PT:351,PR:1,QA:974,RE:262,RO:40,"
      + "RU:7,RW:250,WS:685,SM:378,ST:239,SA:966,SN:221,RS:381,SC:248,SL:232,SG:65,SX:1,SK:421,SI:386,SB:677,SO:252,ZA:27,KR:82,SS:211,ES:34,"
      + "LK:94,BL:590,SH:290,KN:1,LC:1,MF:590,PM:508,VC:1,SD:249,SR:597,SJ:47,SE:46,CH:41,SY:963,TW:886,TJ:992,TZ:255,TH:66,TL:670,TG:228,"
      + "TK:690,TO:676,TT:1,TN:216,TR:90,TM:993,TC:1,TV:688,UG:256,UA:380,AE:971,GB:44,US:1,UY:598,VI:1,UZ:998,VU:678,VA:39,VE:58,VN:84,"
      + "WF:681,EH:212,YE:967,ZM:260,ZW:263";

    public static class Country {
        public final String iso;
        public final int dial;
        public final String name;
        Country(String iso, int dial, String name) { this.iso = iso; this.dial = dial; this.name = name; }
        public String label() { return flag(iso) + "  " + name + "  \u200E+" + dial + "\u200E"; }
    }

    private static Map<String, Integer> table;

    private static synchronized Map<String, Integer> table() {
        if (table == null) {
            table = new LinkedHashMap<>();
            for (String s : DATA.split(",")) {
                String[] p = s.split(":");
                table.put(p[0], Integer.parseInt(p[1]));
            }
        }
        return table;
    }

    public static int dial(String iso) {
        Integer d = table().get(iso);
        return d == null ? 0 : d;
    }

    public static String flag(String iso) {
        if (iso == null || iso.length() != 2) return "\uD83C\uDF10";
        int a = 0x1F1E6 + (Character.toUpperCase(iso.charAt(0)) - 'A');
        int b = 0x1F1E6 + (Character.toUpperCase(iso.charAt(1)) - 'A');
        return new String(Character.toChars(a)) + new String(Character.toChars(b));
    }

    public static String name(String iso, Locale loc) {
        String n = new Locale("", iso).getDisplayCountry(loc);
        return n == null || n.isEmpty() ? iso : n;
    }

    public static List<Country> all(Locale loc) {
        List<Country> out = new ArrayList<>();
        for (Map.Entry<String, Integer> e : table().entrySet())
            out.add(new Country(e.getKey(), e.getValue(), name(e.getKey(), loc)));
        final Collator col = Collator.getInstance(loc);
        Collections.sort(out, (a, b) -> col.compare(a.name, b.name));
        return out;
    }

    /** دولة افتراضية: شريحة الاتصال ثم لغة الجهاز ثم اليمن */
    public static String defaultIso(Context c) {
        try {
            TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) {
                String s = tm.getSimCountryIso();
                if (s != null && s.length() == 2 && table().containsKey(s.toUpperCase(Locale.US))) return s.toUpperCase(Locale.US);
            }
        } catch (Exception ignored) { }
        String l = Locale.getDefault().getCountry();
        if (l != null && table().containsKey(l)) return l;
        return "YE";
    }
}
