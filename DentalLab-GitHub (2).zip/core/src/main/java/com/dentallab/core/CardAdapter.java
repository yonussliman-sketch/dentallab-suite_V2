package com.dentallab.core;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.List;

public class CardAdapter extends BaseAdapter {
    public static class Row {
        public String title, sub, badge;
        public int color;
        public Row(String title, String sub, String badge, int color) {
            this.title = title; this.sub = sub; this.badge = badge; this.color = color;
        }
    }

    private final Context ctx;
    private final List<Row> rows;

    public CardAdapter(Context ctx, List<Row> rows) { this.ctx = ctx; this.rows = rows; }
    @Override public int getCount() { return rows.size(); }
    @Override public Object getItem(int i) { return rows.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int i, View v, ViewGroup parent) {
        if (v == null) v = LayoutInflater.from(ctx).inflate(R.layout.item_card, parent, false);
        Row r = rows.get(i);
        ((TextView) v.findViewById(R.id.tvTitle)).setText(r.title);
        TextView sub = v.findViewById(R.id.tvSub);
        sub.setText(r.sub);
        sub.setVisibility(r.sub == null || r.sub.isEmpty() ? View.GONE : View.VISIBLE);
        TextView badge = v.findViewById(R.id.tvBadge);
        badge.setText(r.badge);
        badge.setVisibility(r.badge == null || r.badge.isEmpty() ? View.GONE : View.VISIBLE);
        badge.setBackground(Ui.pill(r.color));
        return v;
    }
}
