package com.dentallab.core;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.WriteBatch;
import java.util.HashMap;
import java.util.Map;

/** تسجيل الدخول / إنشاء حساب بالبريد وكلمة المرور (Firebase Auth). العيادة تسجّل بنفسها، وأول حساب معمل يصبح المالك. */
public class AuthActivity extends AppCompatActivity {
    private boolean lab, register;
    private EditText etName, etEmail, etPassword;
    private PhoneField phone;
    private View lblPhone;
    private Button btnSave, btnToggle, btnForgot;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_auth);
        Edge.apply(this);
        if (getSupportActionBar() != null) getSupportActionBar().hide();
        lab = getIntent().getBooleanExtra("lab", false);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        phone = findViewById(R.id.phone);
        lblPhone = findViewById(R.id.lblPhone);
        btnSave = findViewById(R.id.btnSave);
        btnToggle = findViewById(R.id.btnToggle);
        btnForgot = findViewById(R.id.btnForgot);
        btnForgot.setOnClickListener(v -> resetPassword());
        ((TextView) findViewById(R.id.tvTitle)).setText(lab ? R.string.auth_title_lab : R.string.auth_title_clinic);
        ((TextView) findViewById(R.id.tvSub)).setText(lab ? R.string.auth_sub_lab : R.string.auth_sub_clinic);
        etName.setHint(lab ? R.string.hint_name_lab : R.string.hint_name_clinic);
        btnToggle.setOnClickListener(v -> { register = !register; updateMode(); });
        btnSave.setOnClickListener(v -> submit());
        updateMode();
    }

    private void updateMode() {
        int vis = register ? View.VISIBLE : View.GONE;
        etName.setVisibility(vis);
        lblPhone.setVisibility(vis);
        phone.setVisibility(vis);
        btnForgot.setVisibility(register ? View.GONE : View.VISIBLE);
        btnSave.setText(register ? R.string.btn_register : R.string.btn_login);
        btnToggle.setText(register ? R.string.toggle_to_login : (lab ? R.string.toggle_to_register_lab : R.string.toggle_to_register));
    }

    private void submit() {
        final String email = etEmail.getText().toString().trim();
        final String pass = etPassword.getText().toString();
        final String name = etName.getText().toString().trim();
        if (email.isEmpty() || pass.length() < 6 || (register && name.isEmpty())) { Ui.toast(this, R.string.err_fields); return; }
        if (register && !phone.isValid()) { Ui.toast(this, R.string.err_phone); return; }
        btnSave.setEnabled(false);
        final String role = lab ? "lab" : "clinic";
        if (register) {
            Repo.auth().createUserWithEmailAndPassword(email, pass).addOnSuccessListener(r -> {
                String uid = Repo.uid();
                Map<String, Object> u = new HashMap<>();
                u.put("name", name); u.put("phone", phone.getE164()); u.put("iso", phone.getIso());
                u.put("national", phone.getNational()); u.put("role", role); u.put("email", email);
                WriteBatch wb = Repo.db().batch();
                wb.set(Repo.db().collection("users").document(uid), u);
                if (lab) {
                    Map<String, Object> owner = new HashMap<>();
                    owner.put("uid", uid);
                    wb.set(Repo.db().collection("config").document("labOwner"), owner);
                }
                wb.commit().addOnSuccessListener(x -> {
                    Profile.save(this, name, phone.getIso(), phone.getNational(), phone.getE164(), role);
                    openMain();
                }).addOnFailureListener(e -> {
                    FirebaseUser fu = Repo.auth().getCurrentUser();
                    if (fu != null) fu.delete();
                    btnSave.setEnabled(true);
                    Ui.toast(this, lab ? getString(R.string.err_lab_exists) : getString(R.string.err_auth, e.getLocalizedMessage()));
                });
            }).addOnFailureListener(this::fail);
        } else {
            Repo.auth().signInWithEmailAndPassword(email, pass).addOnSuccessListener(r ->
                Repo.db().collection("users").document(Repo.uid()).get().addOnSuccessListener(s -> {
                    UserProfile p = s.toObject(UserProfile.class);
                    if (p == null || !role.equals(p.role)) {
                        Repo.auth().signOut();
                        btnSave.setEnabled(true);
                        Ui.toast(this, R.string.err_wrong_app);
                        return;
                    }
                    Profile.save(this, Ui.nz(p.name), Ui.nz(p.iso), Ui.nz(p.national), Ui.nz(p.phone), role);
                    openMain();
                }).addOnFailureListener(this::fail)
            ).addOnFailureListener(this::fail);
        }
    }

    /** استعادة كلمة المرور: يصل رابط إعادة التعيين إلى البريد */
    private void resetPassword() {
        final String email = etEmail.getText().toString().trim();
        if (email.isEmpty()) { Ui.toast(this, R.string.err_reset_email); etEmail.requestFocus(); return; }
        btnForgot.setEnabled(false);
        Repo.auth().sendPasswordResetEmail(email).addOnCompleteListener(t -> {
            btnForgot.setEnabled(true);
            if (t.isSuccessful()) Ui.toast(this, getString(R.string.msg_reset_sent, email));
            else Ui.toast(this, getString(R.string.err_auth, t.getException() == null ? "" : t.getException().getLocalizedMessage()));
        });
    }

    private void fail(Exception e) {
        btnSave.setEnabled(true);
        Ui.toast(this, getString(R.string.err_auth, e.getLocalizedMessage()));
    }

    private void openMain() {
        Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        finish();
    }
}
