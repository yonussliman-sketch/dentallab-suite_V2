package com.dentallab.core;

/** ملف مرفق: إما في Firebase Storage (path) أو مقسّم على Firestore (fid + parts) عند عدم توفر Storage */
public class CaseFile {
    public String name, path, fid;
    public long size;
    public int parts;
    public CaseFile() {}
}
