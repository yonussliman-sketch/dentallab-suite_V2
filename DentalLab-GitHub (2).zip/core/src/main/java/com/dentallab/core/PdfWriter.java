package com.dentallab.core;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.text.TextUtils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** تقرير PDF بجداول (A4 أفقي) بدون مكتبات — يدعم العربية */
public class PdfWriter {
    public static class Section {
        public String heading;
        public String[] header;
        public double[] weights;
        public final List<String[]> rows = new ArrayList<>();
    }

    private static final int W = 842, H = 595, M = 28, ROW = 17;
    private final PdfDocument doc = new PdfDocument();
    private final boolean rtl;
    private final String title;
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG), bold = new Paint(Paint.ANTI_ALIAS_FLAG),
            big = new Paint(Paint.ANTI_ALIAS_FLAG), head = new Paint(Paint.ANTI_ALIAS_FLAG),
            fillHead = new Paint(), fillAlt = new Paint(), line = new Paint(), foot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private PdfDocument.Page page;
    private Canvas cv;
    private int pageNo;
    private float y;

    private PdfWriter(String title, boolean rtl) {
        this.title = title; this.rtl = rtl;
        text.setTextSize(9); bold.setTextSize(9); bold.setTypeface(Typeface.DEFAULT_BOLD);
        big.setTextSize(20); big.setTypeface(Typeface.DEFAULT_BOLD); big.setColor(0xFF00796B);
        head.setTextSize(13); head.setTypeface(Typeface.DEFAULT_BOLD);
        fillHead.setColor(0xFFCDE9E4); fillAlt.setColor(0xFFF3F6F6);
        line.setColor(0xFFB0BEC5); line.setStrokeWidth(0.5f);
        foot.setTextSize(8); foot.setColor(0xFF78909C);
    }

    public static void write(File out, String title, String subtitle, List<Section> sections, boolean rtl) throws IOException {
        PdfWriter w = new PdfWriter(title, rtl);
        w.newPage();
        w.drawTitle(subtitle);
        for (Section s : sections) w.section(s);
        w.finishPage();
        try (FileOutputStream fo = new FileOutputStream(out)) { w.doc.writeTo(fo); }
        w.doc.close();
    }

    private void newPage() {
        pageNo++;
        page = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, pageNo).create());
        cv = page.getCanvas();
        y = M;
    }

    private void finishPage() {
        foot.setTextAlign(rtl ? Paint.Align.RIGHT : Paint.Align.LEFT);
        cv.drawText(title + "  \u2022  " + pageNo, rtl ? W - M : M, H - 12, foot);
        doc.finishPage(page);
    }

    private void drawTitle(String subtitle) {
        big.setTextAlign(rtl ? Paint.Align.RIGHT : Paint.Align.LEFT);
        text.setTextAlign(rtl ? Paint.Align.RIGHT : Paint.Align.LEFT);
        float x = rtl ? W - M : M;
        cv.drawText(title, x, y + 18, big);
        cv.drawText(subtitle, x, y + 34, text);
        y += 50;
    }

    private void section(Section s) {
        if (y > H - M - 70) { finishPage(); newPage(); }
        head.setTextAlign(rtl ? Paint.Align.RIGHT : Paint.Align.LEFT);
        cv.drawText(s.heading, rtl ? W - M : M, y + 12, head);
        y += 20;
        tableHeader(s);
        int i = 0;
        for (String[] r : s.rows) {
            if (y > H - M - ROW) { finishPage(); newPage(); tableHeader(s); }
            if (i++ % 2 == 1) cv.drawRect(M, y, W - M, y + ROW, fillAlt);
            cells(s, r, text);
            y += ROW;
        }
        y += 14;
    }

    private void tableHeader(Section s) {
        cv.drawRect(M, y, W - M, y + ROW + 2, fillHead);
        cells(s, s.header, bold);
        y += ROW + 2;
    }

    private void cells(Section s, String[] vals, Paint p) {
        double total = 0;
        for (double w : s.weights) total += w;
        float avail = W - 2 * M;
        float x = M;
        for (int i = 0; i < vals.length; i++) {
            float cw = (float) (avail * s.weights[i] / total);
            float left = rtl ? (W - M) - (x - M) - cw : x;
            String v = vals[i] == null ? "" : vals[i];
            CharSequence t = TextUtils.ellipsize(v, new android.text.TextPaint(p), cw - 8, TextUtils.TruncateAt.END);
            p.setTextAlign(rtl ? Paint.Align.RIGHT : Paint.Align.LEFT);
            cv.drawText(t.toString(), rtl ? left + cw - 4 : left + 4, y + ROW - 5, p);
            x += cw;
        }
        cv.drawLine(M, y + ROW, W - M, y + ROW, line);
    }
}
