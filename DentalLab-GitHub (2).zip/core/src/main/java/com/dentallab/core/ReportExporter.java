package com.dentallab.core;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.QuerySnapshot;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** تصدير تقرير الحالات والحسابات والدفعات بصيغة PDF أو Excel (للمعمل) — نسخة احتياطية يدوية أيضاً */
public class ReportExporter {
    public static void choose(Activity a) {
        String[] items = {a.getString(R.string.export_pdf), a.getString(R.string.export_excel)};
        new AlertDialog.Builder(a).setTitle(R.string.export_pick)
                .setItems(items, (d, w) -> run(a, w == 0))
                .setNegativeButton(R.string.btn_cancel, null).show();
    }

    private static String day(long t) { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(t)); }

    public static void run(final Activity a, final boolean pdf) {
        final AlertDialog dlg = Ui.busy(a, R.string.msg_export);
        final Task<QuerySnapshot> t1 = Repo.db().collection("cases").get();
        final Task<QuerySnapshot> t2 = Repo.db().collection("users").whereEqualTo("role", "clinic").get();
        final Task<QuerySnapshot> t3 = Repo.db().collection("payments").get();
        Tasks.whenAllSuccess(t1, t2, t3).addOnSuccessListener(res -> {
            final List<CaseItem> cases = t1.getResult().toObjects(CaseItem.class);
            final List<UserProfile> clinics = t2.getResult().toObjects(UserProfile.class);
            final List<Payment> pays = t3.getResult().toObjects(Payment.class);
            new Thread(() -> {
                File f = null;
                Exception err = null;
                try { f = build(a, pdf, cases, clinics, pays); } catch (Exception e) { err = e; }
                final File ff = f;
                final Exception ee = err;
                a.runOnUiThread(() -> {
                    dlg.dismiss();
                    if (ee != null || ff == null) { Ui.toast(a, R.string.err_export); return; }
                    Uri u = FileProvider.getUriForFile(a, a.getPackageName() + ".files", ff);
                    Intent s = new Intent(Intent.ACTION_SEND)
                            .setType(pdf ? "application/pdf" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                            .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    a.startActivity(Intent.createChooser(s, a.getString(R.string.share_title)));
                });
            }).start();
        }).addOnFailureListener(e -> { dlg.dismiss(); Ui.toast(a, R.string.err_export); });
    }

    private static File build(Activity a, boolean pdf, List<CaseItem> cases, List<UserProfile> clinics, List<Payment> pays) throws Exception {
        Collections.sort(cases, (x, y) -> Long.compare(y.createdAt, x.createdAt));
        Collections.sort(pays, (x, y) -> Long.compare(y.createdAt, x.createdAt));
        final boolean rtl = a.getResources().getConfiguration().getLayoutDirection() == android.view.View.LAYOUT_DIRECTION_RTL;
        Map<String, UserProfile> byId = new HashMap<>();
        for (UserProfile u : clinics) byId.put(u.id, u);

        String[] hCases = {a.getString(R.string.col_no), a.getString(R.string.col_date), a.getString(R.string.col_doctor),
                a.getString(R.string.col_patient), a.getString(R.string.col_work), a.getString(R.string.col_teeth),
                a.getString(R.string.col_shade), a.getString(R.string.col_delivery), a.getString(R.string.col_urgent),
                a.getString(R.string.col_status), a.getString(R.string.col_price)};
        String[] hAcc = {a.getString(R.string.col_doctor), a.getString(R.string.col_phone), a.getString(R.string.col_amount_due),
                a.getString(R.string.col_paid), a.getString(R.string.col_balance)};
        String[] hPay = {a.getString(R.string.col_date), a.getString(R.string.col_doctor), a.getString(R.string.col_amount),
                a.getString(R.string.col_note)};

        List<String[]> rCases = new ArrayList<>();
        int n = 0;
        for (CaseItem k : cases) {
            n++;
            rCases.add(new String[]{String.valueOf(n), day(k.createdAt), Ui.nz(k.clinicName), Ui.nz(k.patientRef),
                    Ui.workLabel(a, k.workType), Ui.nz(k.teeth), Ui.nz(k.shade), Ui.nz(k.dueDate),
                    k.urgent ? a.getString(R.string.btn_yes) : "", Ui.statusLabel(a, k.status), Ui.money(k.price)});
        }
        Map<String, double[]> bal = new HashMap<>();
        for (UserProfile u : clinics) bal.put(u.id, new double[2]);
        for (CaseItem k : cases) { double[] b = bal.get(k.clinicId); if (b != null) b[0] += k.price; }
        for (Payment p : pays) { double[] b = bal.get(p.clinicId); if (b != null) b[1] += p.amount; }
        List<String[]> rAcc = new ArrayList<>();
        double td = 0, tp = 0;
        for (UserProfile u : clinics) {
            double[] b = bal.get(u.id);
            td += b[0]; tp += b[1];
            rAcc.add(new String[]{Ui.nz(u.name), Ui.nz(u.phone), Ui.money(b[0]), Ui.money(b[1]), Ui.money(b[0] - b[1])});
        }
        rAcc.add(new String[]{a.getString(R.string.rep_total), "", Ui.money(td), Ui.money(tp), Ui.money(td - tp)});
        List<String[]> rPay = new ArrayList<>();
        for (Payment p : pays) {
            UserProfile u = byId.get(p.clinicId);
            rPay.add(new String[]{day(p.createdAt), u == null ? "" : Ui.nz(u.name), Ui.money(p.amount), Ui.nz(p.note)});
        }

        File dir = new File(a.getCacheDir(), "exports");
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File o : old) o.delete();
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
        File out = new File(dir, "DentalLab_Report_" + stamp + (pdf ? ".pdf" : ".xlsx"));
        String sub = a.getString(R.string.rep_generated, new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()),
                Profile.name(a));

        if (pdf) {
            List<PdfWriter.Section> secs = new ArrayList<>();
            PdfWriter.Section s1 = new PdfWriter.Section();
            s1.heading = a.getString(R.string.sheet_accounts); s1.header = hAcc; s1.weights = new double[]{3, 3, 2, 2, 2};
            s1.rows.addAll(rAcc); secs.add(s1);
            PdfWriter.Section s2 = new PdfWriter.Section();
            s2.heading = a.getString(R.string.sheet_cases); s2.header = hCases;
            s2.weights = new double[]{0.7, 1.6, 2.4, 2.2, 2.4, 2.4, 1, 1.6, 1, 1.8, 1.2};
            s2.rows.addAll(rCases); secs.add(s2);
            PdfWriter.Section s3 = new PdfWriter.Section();
            s3.heading = a.getString(R.string.sheet_payments); s3.header = hPay; s3.weights = new double[]{2, 4, 2, 5};
            s3.rows.addAll(rPay); secs.add(s3);
            PdfWriter.write(out, a.getString(R.string.report_title), sub, secs, rtl);
        } else {
            List<XlsxWriter.Sheet> sheets = new ArrayList<>();
            XlsxWriter.Sheet x1 = new XlsxWriter.Sheet(a.getString(R.string.sheet_cases));
            x1.widths = new int[]{5, 12, 22, 20, 20, 24, 8, 12, 8, 16, 10};
            x1.rows.add(hCases);
            for (String[] r : rCases) {
                Object[] o = new Object[r.length];
                for (int i = 0; i < r.length; i++) o[i] = (i == 0 || i == 10) ? (Object) Ui.num(r[i]) : r[i];
                x1.rows.add(o);
            }
            sheets.add(x1);
            XlsxWriter.Sheet x2 = new XlsxWriter.Sheet(a.getString(R.string.sheet_accounts));
            x2.widths = new int[]{24, 18, 14, 14, 14};
            x2.rows.add(hAcc);
            for (String[] r : rAcc) x2.rows.add(new Object[]{r[0], r[1], Ui.num(r[2]), Ui.num(r[3]), Ui.num(r[4])});
            sheets.add(x2);
            XlsxWriter.Sheet x3 = new XlsxWriter.Sheet(a.getString(R.string.sheet_payments));
            x3.widths = new int[]{12, 24, 14, 30};
            x3.rows.add(hPay);
            for (String[] r : rPay) x3.rows.add(new Object[]{r[0], r[1], Ui.num(r[2]), r[3]});
            sheets.add(x3);
            XlsxWriter.write(out, sheets, rtl);
        }
        return out;
    }
}
