package com.dentallab.core;
import android.content.Context;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.List;

/** إشعارات فورية أثناء عمل التطبيق (والخلفية عبر Cloud Functions اختيارياً) */
public class Watcher {
    private interface OnChange { void run(DocumentChange c); }

    public static List<ListenerRegistration> start(Context ctx, boolean lab) {
        final Context app = ctx.getApplicationContext();
        List<ListenerRegistration> regs = new ArrayList<>();
        Query cases = Repo.db().collection("cases");
        Query appts = Repo.db().collection("appointments");
        if (!lab) {
            cases = cases.whereEqualTo("clinicId", Repo.uid());
            appts = appts.whereEqualTo("clinicId", Repo.uid());
        }
        regs.add(watch(cases, c -> {
            CaseItem k = c.getDocument().toObject(CaseItem.class);
            if (!lab && c.getType() == DocumentChange.Type.MODIFIED)
                Notifier.show(app, app.getString(R.string.notif_case_update),
                        app.getString(R.string.notif_body, Ui.workLabel(app, k.workType), Ui.statusLabel(app, k.status)));
            if (lab && c.getType() == DocumentChange.Type.ADDED)
                Notifier.show(app, (k.urgent ? "\u26A1 " : "") + app.getString(R.string.notif_new_case),
                        app.getString(R.string.notif_body, Ui.nz(k.clinicName), Ui.workLabel(app, k.workType)));
        }));
        regs.add(watch(appts, c -> {
            Appointment a = c.getDocument().toObject(Appointment.class);
            if (!lab && c.getType() == DocumentChange.Type.MODIFIED)
                Notifier.show(app, app.getString(R.string.notif_appt_update),
                        app.getString(R.string.notif_body, Ui.nz(a.date), Ui.apptLabel(app, a.status)));
            if (lab && c.getType() == DocumentChange.Type.ADDED)
                Notifier.show(app, app.getString(R.string.notif_new_appt),
                        app.getString(R.string.notif_body, Ui.nz(a.clinicName), Ui.nz(a.date) + " " + Ui.nz(a.time)));
        }));
        return regs;
    }

    private static ListenerRegistration watch(Query q, OnChange cb) {
        final boolean[] first = {true};
        return q.addSnapshotListener((snap, e) -> {
            if (snap == null) return;
            if (first[0]) { first[0] = false; return; }
            for (DocumentChange c : snap.getDocumentChanges()) {
                if (c.getDocument().getMetadata().hasPendingWrites()) continue;
                cb.run(c);
            }
        });
    }
}
