package com.dentallab.core;
import android.app.Activity;
import android.content.Intent;
import android.text.InputType;
import android.widget.EditText;
import android.widget.FrameLayout;
import androidx.appcompat.app.AlertDialog;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

/** تسجيل الخروج وحذف الحساب (مطلوب في Google Play) */
public class AccountUtil {
    private static void toAuth(Activity a, boolean lab) {
        Intent i = new Intent(a, AuthActivity.class).putExtra("lab", lab)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        a.startActivity(i);
        a.finish();
    }

    public static void logout(Activity a, boolean lab) {
        Push.unregister(lab);
        Repo.auth().signOut();
        Profile.clear(a);
        toAuth(a, lab);
    }

    public static void deleteAccount(Activity a, boolean lab) {
        final EditText pw = new EditText(a);
        pw.setHint(R.string.hint_password);
        pw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        FrameLayout box = new FrameLayout(a);
        int p = (int) (20 * a.getResources().getDisplayMetrics().density);
        box.setPadding(p, p / 2, p, 0);
        box.addView(pw);
        new AlertDialog.Builder(a).setTitle(R.string.delete_title).setMessage(R.string.delete_msg).setView(box)
                .setPositiveButton(R.string.btn_delete, (d, w) -> run(a, lab, pw.getText().toString()))
                .setNegativeButton(R.string.btn_cancel, null).show();
    }

    private static void run(Activity a, boolean lab, String password) {
        final FirebaseUser u = Repo.auth().getCurrentUser();
        if (u == null || u.getEmail() == null || password.isEmpty()) { Ui.toast(a, R.string.err_delete); return; }
        final AlertDialog dlg = Ui.busy(a, R.string.msg_wait);
        AuthCredential cred = EmailAuthProvider.getCredential(u.getEmail(), password);
        u.reauthenticate(cred).addOnSuccessListener(x -> {
            final String uid = u.getUid();
            final Runnable finish = () -> u.delete().addOnSuccessListener(y -> {
                dlg.dismiss();
                Push.unregister(lab);
                Profile.clear(a);
                toAuth(a, lab);
            }).addOnFailureListener(e -> { dlg.dismiss(); Ui.toast(a, R.string.err_delete); });
            final Runnable deleteUserDoc = () ->
                    Repo.db().collection("users").document(uid).delete().addOnCompleteListener(t -> finish.run());
            if (lab) {
                Repo.db().collection("config").document("labOwner").delete().addOnCompleteListener(t -> deleteUserDoc.run());
            } else {
                Repo.db().collection("appointments").whereEqualTo("clinicId", uid).get().addOnSuccessListener(snap -> {
                    WriteBatch wb = Repo.db().batch();
                    for (DocumentSnapshot ds : snap.getDocuments()) wb.delete(ds.getReference());
                    wb.commit().addOnCompleteListener(t -> deleteUserDoc.run());
                }).addOnFailureListener(e -> deleteUserDoc.run());
            }
        }).addOnFailureListener(e -> { dlg.dismiss(); Ui.toast(a, R.string.err_delete); });
    }
}
