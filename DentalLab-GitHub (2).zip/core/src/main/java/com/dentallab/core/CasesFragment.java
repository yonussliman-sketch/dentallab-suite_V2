package com.dentallab.core;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.WriteBatch;
import android.widget.Button;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** قائمة الحالات (لحظية). العيادة ترى حالاتها، والمعمل يرى الكل مع بحث وفلترة بالحالة. */
public class CasesFragment extends Fragment {
    private boolean lab;
    private ListView list;
    private Spinner spFilter;
    private Button btnReceiveAll;
    private EditText etSearch;
    private ListenerRegistration reg;
    private final List<CaseItem> all = new ArrayList<>();
    private List<CaseItem> shown = new ArrayList<>();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_cases, c, false);
        lab = ((Host) requireActivity()).isLab();
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        spFilter = v.findViewById(R.id.spFilter);
        btnReceiveAll = v.findViewById(R.id.btnReceiveAll);
        etSearch = v.findViewById(R.id.etSearch);

        if (lab) {
            v.findViewById(R.id.filterBar).setVisibility(View.VISIBLE);
            List<String> opts = new ArrayList<>();
            opts.add(getString(R.string.all_statuses));
            for (String st : Ui.statusLabels(requireContext(), 1)) opts.add(st);
            spFilter.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, opts));
            spFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override public void onItemSelected(AdapterView<?> p, View view, int pos, long id) { apply(); }
                @Override public void onNothingSelected(AdapterView<?> p) { }
            });
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence a, int b, int c2, int d) { }
                @Override public void onTextChanged(CharSequence a, int b, int c2, int d) { apply(); }
                @Override public void afterTextChanged(Editable e) { }
            });
        }
        list.setOnItemClickListener((p, view, pos, id) ->
                startActivity(new Intent(requireContext(), CaseDetailActivity.class)
                        .putExtra("id", shown.get(pos).id).putExtra("lab", lab)));

        Query q = Repo.db().collection("cases");
        if (!lab) q = q.whereEqualTo("clinicId", Repo.uid());
        reg = q.addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            all.clear();
            all.addAll(snap.toObjects(CaseItem.class));
            Collections.sort(all, (a, b) -> Long.compare(b.createdAt, a.createdAt));
            apply();
        });
        return v;
    }

    /** المعمل: استلام كل الحالات الجديدة دفعة واحدة */
    private void receiveAll() {
        WriteBatch wb = Repo.db().batch();
        long now = System.currentTimeMillis();
        for (CaseItem k : all) if (k.status == 1)
            wb.update(Repo.db().collection("cases").document(k.id), "status", 2, "receivedAt", now, "updatedAt", now);
        wb.commit().addOnSuccessListener(x -> Ui.toast(requireContext(), R.string.toast_received));
    }

    private void apply() {
        if (!isAdded()) return;
        if (lab) {
            int fresh = 0;
            for (CaseItem k : all) if (k.status == 1) fresh++;
            btnReceiveAll.setVisibility(fresh > 0 ? View.VISIBLE : View.GONE);
            btnReceiveAll.setText(getString(R.string.btn_receive_all, fresh));
            btnReceiveAll.setOnClickListener(x -> receiveAll());
        }
        String q = lab ? etSearch.getText().toString().trim().toLowerCase(Locale.getDefault()) : "";
        int f = lab ? spFilter.getSelectedItemPosition() : 0;
        shown = new ArrayList<>();
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (CaseItem k : all) {
            if (f > 0 && k.status != f) continue;
            String hay = (Ui.nz(k.clinicName) + " " + Ui.nz(k.patientRef) + " " + Ui.nz(k.teeth)).toLowerCase(Locale.getDefault());
            if (!q.isEmpty() && !hay.contains(q)) continue;
            shown.add(k);
            int nf = k.files == null ? 0 : k.files.size();
            String ref = Ui.nz(k.patientRef).trim();
            String sub = (lab ? Ui.workLabel(requireContext(), k.workType) + (ref.isEmpty() ? "" : " \u2014 " + ref) + "\n" : "")
                    + "\uD83E\uDDB7 " + Ui.nz(k.teeth)
                    + (Ui.nz(k.dueDate).isEmpty() ? "" : "\n\uD83D\uDCC5 " + k.dueDate)
                    + (nf > 0 ? "   \uD83D\uDCCE " + nf : "");
            rows.add(new CardAdapter.Row((k.urgent ? "\u26A1 " : "") + Ui.caseTitle(requireContext(), k, lab), sub,
                    Ui.statusLabel(requireContext(), k.status), Ui.statusColor(k.status)));
        }
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }

    @Override public void onDestroyView() {
        if (reg != null) reg.remove();
        super.onDestroyView();
    }
}
